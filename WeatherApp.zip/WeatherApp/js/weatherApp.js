/* Weather Forcast module */
var app = angular.module('WeatherApp', []);

/* Weather Forcast controller starts */
app.controller('MyModuleWeather', function($scope, $http, $log) {
    // Set default values for our form fields.
    $scope.city = '';
    $scope.units = 'metric';
    $scope.country = 'IN';
    $scope.arrList = [];
    $scope.records = [];
    // Define a function to process form submission.
    $scope.change = function() {
        // Fetch the data from the public API through JSONP.
        // See http://openweathermap.org/API#weather.
        var url = 'http://api.openweathermap.org/data/2.5/weather?q=' + $scope.city + ',' + $scope.country + '&APPID=7b1d759bc5056ad8117e7723b05dfa5e';

            // url (required), options (optional)
       fetch(url)
      .then((resp) => resp.json())
      .then(function(data) {

                         $scope.name = data.name;

                         $scope.main = data.main.temp;

                         $scope.weather = data.weather[0];

                         $scope.wind = data.wind;
                         alert($scope.wind);
                         $scope.clouds = data.clouds;
                         $scope.coord = data.coord;

                
            }).catch(function(error) {
                // Error :(
                       // Log an error in the browser's console.
                  console.log(error);

            });





        






        $scope.showme = 'true';

    };












    $scope.searchList = function() {

        var getItems = JSON.parse(localStorage.getItem("item"));
        var getItemsLength = getItems.length;
        //alert(getItems);
        for (var i = 0; i < getItemsLength; i++) {
            if (getItemsLength <= 5) {
                $scope.records.push(angular.copy(getItems[i]));
            }
        }
    }


    /*Function for Temperature Change*/
    $scope.tempChange = function() {
        // Fetch the data from the public API through JSONP.
        // See http://openweathermap.org/API#weather.
        var url = 'http://api.openweathermap.org/data/2.5/weather?q=' + $scope.city + ',' + $scope.country + '&APPID=7b1d759bc5056ad8117e7723b05dfa5e';

        $http.jsonp(url, {
            params: {
                q: $scope.city,
                units: $scope.units,
                callback: 'JSON_CALLBACK'
            }
        }).
        success(function(data, status, headers, config) {
            $scope.main = data.main;
        }).
        error(function(data, status, headers, config) {
            // Log an error in the browser's console.
            $log.error('Could not retrieve data from ' + url);
        });

    };

    /*Ends Function for Temperature Change*/


});
