//Function for Add to bucket
$("#tableData").on('click', '.deleteRow', function() {
    // alert('dsd');
    $(this).closest('tr').remove();
});
var leavedataArr = [];

function leaveDetails() {
    var rows = "";
    var leaveType = document.getElementById("leaveType").value;
    var startDate = document.getElementById('startDate').valueAsDate;
    var endDate = document.getElementById('endDate').valueAsDate;
    var reasonLeave = document.getElementById("reasonLeave").value;
    var contactNo = document.getElementById("contactNo").value;
    var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var sdayName = days[startDate.getDay()];
    var edayName = days[endDate.getDay()];
    var startDateFormet = startDate.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    }).split(' ').join('-');
    var endDateFormet = endDate.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    }).split(' ').join('-');
    var diffDays = workDaysBetweenDates(startDate, endDate);
    $(".Duration").html("Duration:" + diffDays);
    var deleteButton = "<a href='JavaScript:void(0)' title='delete' class='deleteRow'><img src='img/delete.png' alt='delete' title='delete' class='logout img-responsive'/></a>";
    var leaveTypeSelect = "<select class='form-control' disabled='disabled'><option>" + leaveType + "</option></select>";

    rows += "<tr><td>" + startDateFormet + "</td><td>" + sdayName + "</td><td class='text-center'><span class='checkboxButton'></span></td><td class='text-center'>" + leaveTypeSelect + "</td><td class='text-center'>" + deleteButton + "</td></tr><tr><td>" + endDateFormet + "</td><td>" + edayName + "</td><td class='text-center'><span class='checkboxButton'></span></td><td class='text-center'>" + leaveTypeSelect + "</td><td class='text-center'>" + deleteButton + "</td></tr>";

    $(rows).appendTo("#tableData tbody");

    leavedataArr.push(startDateFormet, endDateFormet, sdayName, edayName, leaveType, contactNo);

}



// Logic for calculate working day

function workDaysBetweenDates(startDate, endDate) {
    var millisecondsPerDay = 86400 * 1000;
    startDate.setHours(0, 0, 0, 1);
    endDate.setHours(23, 59, 59, 999);
    var diff = endDate - startDate;
    var days = Math.ceil(diff / millisecondsPerDay);

    var weeks = Math.floor(days / 7);
    days = days - (weeks * 2);

    var startDay = startDate.getDay();
    var endDay = endDate.getDay();

    // Remove weekend if not previously removed.
    if (startDay - endDay > 1)
        days = days - 2;

    // Remove start day if span starts on Sunday but ends before Saturday
    if (startDay === 0 && endDay !== 6)
        days = days - 1;

    // Remove end day if span ends on Saturday but starts after Sunday
    if (endDay === 6 && startDay !== 0)
        days = days - 1;

    if (startDay - endDay == 0)
        days = days - 0.5;


    return days;
}

function searchDay() {
    // Declare variables 
    var searchInput, filter, table, tr, td, i;
    searchInput = document.getElementById("searchInput");
    filter = searchInput.value.toUpperCase();
    table = document.getElementById("leaveTable");
    tr = table.getElementsByTagName("tr");
    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[1];

        if (td) {
            if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}


$(".submitButtonaArea").on('click', '.submitData', function() {

    //var data = 'Start Date='+ startDate; 

    $.ajax({
        type: "POST",
        url: "leavedetails.html",
        success: function() {
            alert("Your data send successfully.\nData is ::" + leavedataArr);
        }
    });
    return false;


});