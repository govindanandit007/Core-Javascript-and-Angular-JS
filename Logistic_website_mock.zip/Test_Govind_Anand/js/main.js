// Code For submenu navigation
$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
    if (!$(this).next().hasClass('show')) {
      $(this).parents('.dropdown-menu').first().find('.show').removeClass('show');
    }
    var $subMenu = $(this).next('.dropdown-menu');
    $subMenu.toggleClass('show');

    $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
      $('.dropdown-submenu .show').removeClass('show');
    });
    return false;
});

$('.nav-item').hover(function(e) {
    $('.nav-item').removeClass('active');
    $(this).addClass('active');
});

// For Slider Start
$('.carousel,#clientSlider,#testimonialSlider').carousel();

// For Client Slider
$('#clientSlides').on('slide.bs.carousel', function (e) {
    var $e = $(e.relatedTarget);
    var idx = $e.index();
    var itemsPerSlide = 4;
    var totalItems = $('.carousel-item').length;
 
    if (idx >= totalItems-(itemsPerSlide-1)) {
        var it = itemsPerSlide - (totalItems - idx);
        for (var i=0; i<it; i++) {
            // append slides to end
            if (e.direction=="left") {
                $('#clientSlides .carousel-item').eq(i).appendTo('#clientSlides .carousel-inner');
            }
            else {
                $('#clientSlides .carousel-item').eq(0).appendTo('#clientSlides .carousel-inner');
            }
        }
    }
});

// For Video Controls in firefox
var vids = $("video"); 
$.each(vids, function(){
    this.controls = false; 
}); 
// For Video Controls in chrome
$("video").click(function() {
  if (this.paused) {
    this.play();
  } else {
    this.pause();
  }
});

// For header Position
$(document).scroll(function(){
  var scrollPos = $(document).scrollTop();
  var mainSider = $('.SliderArea').outerHeight();
  if(scrollPos > 10){
    $('header').addClass('headerBackground');
    $('#dropdownNav').addClass('darkBackgroundNav');
  }else{
    $('header').removeClass('headerBackground');
    $('#dropdownNav').removeClass('darkBackgroundNav');
  }
});

// For Media Query
$(document).ready(function(){
  var largeScreen = window.matchMedia("(min-width: 800px)")
  
  if (largeScreen.matches) { 
    // If media query matches
    $('header').addClass('fixed-top');
    $('header').removeClass('mobileMenu');
  } else {
    $('header').removeClass('fixed-top');
    $('header').addClass('mobileMenu');
  }
});
